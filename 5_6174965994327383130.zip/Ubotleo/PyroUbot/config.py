import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "400"))

DEVS = list(map(int, os.getenv("DEVS", "7605760758").split()))

API_ID = int(os.getenv("API_ID", "32207834"))

API_HASH = os.getenv("API_HASH", "940f53dc43803180120961f3dcc466af")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8307507664:AAEPS7od3oevS6Zrrr-2h8sfWNT7ZFA2anM")

OWNER_ID = int(os.getenv("OWNER_ID", "7605760758"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003192483568").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://alpattr:alfathgg123@alpattr.d0v5gm3.mongodb.net/?appName=alpattr")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002952717963"))
