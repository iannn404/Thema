from PyroUbot import *

__MODULE__ = "font"
__HELP__ = """
perintah : <code>{0}font</code>
    reply text, merubah text menjadi berbeda</blockquote>
"""

